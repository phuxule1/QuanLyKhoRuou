<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class nhacungcap extends Model
{
    protected $table='nhacungcap';
    protected $fillable = [
        'TenNCC',
    ];
}
