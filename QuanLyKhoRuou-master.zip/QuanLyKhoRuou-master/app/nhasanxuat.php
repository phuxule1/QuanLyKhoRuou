<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class nhasanxuat extends Model
{
    protected $table='nhasanxuat';
    protected $fillable = [
        'TenNSX',
    ];
}
