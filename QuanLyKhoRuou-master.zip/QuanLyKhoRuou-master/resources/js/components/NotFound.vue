<template>
    <div>
        <h2>Không đủ quyền để truy cập</h2>
    </div>
</template>