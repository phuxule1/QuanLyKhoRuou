@extends('layouts.app')

@section('content')
<div class="app-title">
    <div>
        <h1><i class="fa fa-dashboard"></i> Blank Page</h1>
        <p>Start a beautiful journey here</p>
    </div>
    <ul class="app-breadcrumb breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
        <li class="breadcrumb-item"><a href="#">Blank Page</a></li>
    </ul>
</div>
<div class="row">
    <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12" style="margin-bottom:15px">
        <div class="card" style="width: 100%">
            <img class="card-img-top" src="http://file.vforum.vn/hinh/2018/02/top-nhung-hinh-anh-an-vy-hinh-nen-an-vy-dep-nhat-de-thuong-3.png" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
        </div>
    </div>

    <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12" style="margin-bottom:15px">
        <div class="card" style="width: 100%">
            <img class="card-img-top" src="http://file.vforum.vn/hinh/2018/02/top-nhung-hinh-anh-an-vy-hinh-nen-an-vy-dep-nhat-de-thuong-3.png" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
        </div>
    </div>

    <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12" style="margin-bottom:15px">
        <div class="card" style="width: 100%">
            <img class="card-img-top" src="http://file.vforum.vn/hinh/2018/02/top-nhung-hinh-anh-an-vy-hinh-nen-an-vy-dep-nhat-de-thuong-3.png" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
        </div>
    </div>

    <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12" style="margin-bottom:15px">
        <div class="card" style="width: 100%">
            <img class="card-img-top" src="http://file.vforum.vn/hinh/2018/02/top-nhung-hinh-anh-an-vy-hinh-nen-an-vy-dep-nhat-de-thuong-3.png" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
        </div>
    </div>

    <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12" style="margin-bottom:15px">
        <div class="card" style="width: 100%">
            <img class="card-img-top" src="http://file.vforum.vn/hinh/2018/02/top-nhung-hinh-anh-an-vy-hinh-nen-an-vy-dep-nhat-de-thuong-3.png" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
        </div>
    </div>

    <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12" style="margin-bottom:15px">
        <div class="card" style="width: 100%">
            <img class="card-img-top" src="http://file.vforum.vn/hinh/2018/02/top-nhung-hinh-anh-an-vy-hinh-nen-an-vy-dep-nhat-de-thuong-3.png" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
        </div>
    </div>

    <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12" style="margin-bottom:15px">
        <div class="card" style="width: 100%">
            <img class="card-img-top" src="http://file.vforum.vn/hinh/2018/02/top-nhung-hinh-anh-an-vy-hinh-nen-an-vy-dep-nhat-de-thuong-3.png" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
        </div>
    </div>

    <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12" style="margin-bottom:15px">
        <div class="card" style="width: 100%">
            <img class="card-img-top" src="http://file.vforum.vn/hinh/2018/02/top-nhung-hinh-anh-an-vy-hinh-nen-an-vy-dep-nhat-de-thuong-3.png" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
        </div>
    </div>

    <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12" style="margin-bottom:15px">
        <div class="card" style="width: 100%">
            <img class="card-img-top" src="http://file.vforum.vn/hinh/2018/02/top-nhung-hinh-anh-an-vy-hinh-nen-an-vy-dep-nhat-de-thuong-3.png" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
        </div>
    </div>
</div>
@endsection
